Integrantes Trabajo en Equipo:

- Alejandra Jorquera
- Nahara Gutiérrez
- Katherin Meza
